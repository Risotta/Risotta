<!DOCTYPE html>
<html>
 <head>
  <base href=""/>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport"/>
  <title>
   MANJARE
  </title>
  <link href="favicon.ico" rel="shortcut icon" type="image/x-icon"/>
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,900&display=swap&subset=cyrillic-ext" rel="stylesheet"/>
  <script>
   window.jQuery || document.write('<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"><\/script>')
  </script>
  <script>
   window.jQuery || document.write('<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.1.4.min.js"><\/script>')
  </script>
  <script charset="utf-8" src="js/phone-codes.js">
  </script>
  <script charset="utf-8" src="js/jquery.mask.min.js">
  </script>
  <script charset="utf-8" src="js/common_new.js">
  </script>
  <script charset="utf-8" src="js/1.js">
  </script>
  <script>
   var site_title = "MANJARE, заказать на официальном сайте"
  </script>
 
  <link href="css/styles.css" rel="stylesheet"/>
 </head>
 <body>
  <script src="js/geoip.js">
  </script>
  <div class="overflow-x">
   <header>
    <div class="wrapper">
     <div class="header-title">
      <img alt="" class="header-title__img" src="img/header-title.png"/>
     </div>
    </div>
   </header>
   <main>
    <div class="wrapper">
     <div class="col-left">
       
         <h1 class="h1">
       
     <p>“კვება”… როცა ეს სიტყვა გვესმის, შეიძლება წინადადების გაგრძელება აღარც მოვისმინოთ. ჩვენი კვება უმეტესად იმდენად ინსტინქტურია, რომ არ ვაქცევთ ყურადღებას რას, როდის და რა რაოდენობით ვჭამთ.
     <br><br>
     <img src="img/logo.png" height="300" width="300">
     <br><br>
     თუმცა, კვება უმნიშვნელოვანესია. ჯანმრთელობის მნიშვნელობაზე ლაპარაკი ალბათ ზედმეტი იქნება და ამიტომ ჯობია პირდაპირ ვთქვათ, რომ მის შესანარჩუნებლად ყველაზე მნიშვნელოვანი სწორედ კვებაა. ვერანაირი ვარჯიში, სუფთა ჰაერი და მშვიდი ცხოვრება ჯანმრთელობაზე დადებით გავლენას ვერ მოახდენს, თუ ამ ყველაფერს არ ერთვის სწორი კვება. 
    <br><br>
     <img src="img/123.jpg" height="500" width="500">
     <br><br>
     ეს ორი სიტყვა მარტივი დასამახსოვრებელი და გამოსათქმელია, მაგრამ შესასრულებლად რთულია. იმისთვის, რომ ადამიანმა სწორად იკვებოს, ყურადღება, ნებისყოფა და გარკვეული ცოდნაც სჭირდება. 
      <br><br>
     <img src="img/rad1.jpg" height="500" width="500">
     <br><br>
     აქ მნიშვნელოვანია არა მარტო ის, თუ რას ვჭამთ, არამედ ისიც, თუ რა დროს ვჭამთ, რა რაოდენობით ვჭამთ, რა თანმიმდევრობით ვღებულობთ საკვებს, ხილს, სასმელს. მნიშვნელოვანია იმის გათავისება, რომ რაც უნდა ჯანსაღი საკვები მივიღოთ, თუ ამას სათანადო დროს და სათანადო წესით არ გავაკეთებთ, არანაირი შედეგი არ გვექნება. ასევე ძალიან მნიშვნელოვანია, ვიცოდეთ ჩვენი ორგანიზმის თვისებები, თავისებურებები და ამის შესაბამისად მივიღოთ ის (შეძლებისდაგვარად), რაც ყველაზე მეტად გვარგებს, რა თქმა უნდა, ზომიერი რაოდენობით.</p>
      <br><br>
     <img src="img/rad2.jpg" height="500" width="500">
     <br><br>
     </h1>
     
     </div>
     <div class="col-right">
      <div class="col-right__content">
       <h1 class="h1">
        აკონტროლეთ თქვენი წონა
        <div class="uppercase">
         MANJARE
        </div>
       </h1>
       <div class="form-wrap">
        <div class="form-wrap__content">
         <p class="form-text">
წონის კორექციის პროგრამაზე დარეგისტრირებისთვის, თქვენი ტელეფონის ნომერი და სახელი ფორმაში დატოვეთ ვებ – გვერდზე
  <b>
          და დააჭირეთ გაგზავნას 
          </b>
          .
         </p>
         <form action="order.php<?php if (!empty($_GET)) echo '?'.http_build_query($_GET);?>" class="form" id="form" method="post">
          <select class="form__input form__input_select country" id="country" name="country">
           <option price1="9100" price2="1500" price3="18200" pricecurrency=" драм" value="AM">
            Армения
           </option>
           <option price1="35" price2="5" price3="70" pricecurrency=" бел. р." value="BY">
            Беларусь
           </option>
           <option price1="24" price2="10" price3="48" pricecurrency=" EUR" value="EE">
            Эстония
           </option>
           <option price1="60" price2="7" price3="120" pricecurrency=" gel" value="GE">
            Грузия
           </option>
           <option price1="1660" price2="300" price3="3380" pricecurrency=" сом" value="KG">
            Киргизия
           </option>
           <option price1="5990" price2="1500" price3="11980" pricecurrency=" тенге" value="KZ">
            Казахстан
           </option>
           <option price1="18" price2="10" price3="36" pricecurrency=" EUR" value="LT">
            Литва
           </option>
           <option price1="24" price2="10" price3="48" pricecurrency=" EUR" value="LV">
            Латвия
           </option>
           <option price1="200" price2="35" price3="400" pricecurrency=" сом" value="TJ">
            Таджикистан
           </option>
           <option price1="450" price2="50" price3="900" pricecurrency=" грн." value="UA">
            Украина
           </option>
           <option price1="135000" price2="25000" price3="270000" pricecurrency=" UZS" value="UZ">
            Узбекистан
           </option>
           <option price1="9100" price2="1500" price3="18200" pricecurrency=" драм" value="NL">
            Нидерланды
           </option>
          </select>
          <div class="form__item relative">
           <input class="form__input" id="name" name="fio" placeholder="სახელი" type="text"/>
          </div>
          <div class="form__item relative">
           <input class="form__input only_number" id="phone" name="phone" placeholder="ტელეფონის ნომერი" type="text"/>
          </div>
          <button class="btn js_submit">
           გაუგზავნე
          </button>
          <input name="trf_dt" type="hidden" value="c2l0ZV9pZD02Njcy"/>
          <input name="address" type="hidden" value=""/>
          <input name="site_data" type="hidden" value="6672"/>
          <input name="uniq_id" type="hidden" value="79ab5d1b0b038ac0c04ef16edc04c749"/>
          <input name="no_country" type="hidden" value="1"/>
          <input name="added_country" type="hidden" value="AM"/>
         </form>
        </div>
       </div>
       <p class="form-text form-text_footer">
     ჩვენ დაგიკავშირდებით 15 წუთის განმავლობაში დეტალური კონსულტაციისა და დეტალების დასაზუსტებლად.
  <br><br><br>
      <center>  <div class="politic"> <a href="privacy.html" >Privacy policy</a></div></center>
   <br>
    <center>  <div class="politic"> <a href="terms.html" >Terms & Conditions</a></div></center>
    <br>
        <center>  <div class="politic"> <a href="EULA.html" >Agreement (EULA)</a></div></center>
   
       </p>
      </div>
     </div>
    </div>
   </main>
   
   <footer>
       <br><br><br>
    
   </footer>
  </div>
  <script src="js/chekerab.js" type="text/javascript">
  </script>
    <center><p class="form-text form-text_footer">
       ООО <Солярий>
       <br/>
       136151, г.Санкт-Петербург,
       <br/>
       Тверская 3-я улица, 31, стр.1
       <br/>
       ИНН 77109123456
       <br/>
       ОГРН 11377432156825 от 1 мая 2001
      </p></center>
      <br><br><br>
      <right>
          <center>  <div class="politic"> <a href="privacy.html" >Privacy policy</a></div></center>
   <br>
    <center>  <div class="politic"> <a href="terms.html" >Terms & Conditions</a></div></center>
    <br>
        <center>  <div class="politic"> <a href="EULA.html" >Agreement (EULA)</a></div></center>
   
      </right>
      <style type="text/css">#cookie_notification{
  display: none;
  justify-content: space-between;
  align-items: flex-end;
  position: fixed;
  bottom: 15px;
  left: 50%;
  width: 900px;
  max-width: 90%;
  transform: translateX(-50%);
  padding: 25px;
  background-color: white;
  border-radius: 4px;
  box-shadow: 2px 3px 10px rgba(0, 0, 0, 0.4);
}

#cookie_notification p{
  margin: 0;
  font-size: 0.7rem;
  text-align: left;
  color: $color_text;
}


@media (min-width: 576px){
  #cookie_notification.show{
    display: flex;
  }
  .cookie_accept{
    margin: 0 0 0 25px;
  }
}

@media (max-width: 575px){
  #cookie_notification.show{
    display: block;
    text-align: left;
  }
  .cookie_accept{
    margin: 10px 0 0 0;
  }
}</style>

  <div id="cookie_notification" class="">
        <p>Для улучшения работы сайта и его взаимодействия с пользователями мы используем файлы cookie. Продолжая работу с сайтом, Вы разрешаете использование cookie-файлов. Вы всегда можете отключить файлы cookie в настройках Вашего браузера.</p>
        <button class="button cookie_accept">Принять</button>
</div>

    <script type="text/javascript">//<![CDATA[


function checkCookies(){
    let cookieDate = localStorage.getItem('cookieDate');
    let cookieNotification = document.getElementById('cookie_notification');
    let cookieBtn = cookieNotification.querySelector('.cookie_accept');

    // Если записи про кукисы нет или она просрочена на 1 год, то показываем информацию про кукисы
    if( !cookieDate || (+cookieDate + 31536000000) < Date.now() ){
        cookieNotification.classList.add('show');
    }

    // При клике на кнопку, в локальное хранилище записывается текущая дата в системе UNIX
    cookieBtn.addEventListener('click', function(){
        localStorage.setItem( 'cookieDate', Date.now() );
        cookieNotification.classList.remove('show');
    })
}
checkCookies();


  //]]></script>
 </body>
</html>